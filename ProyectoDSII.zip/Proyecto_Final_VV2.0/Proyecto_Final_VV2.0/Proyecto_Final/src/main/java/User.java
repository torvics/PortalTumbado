public class User {
    String nombres;
    String apellidos;
    String telefono;
    String email;
    String contraseña;
    int calificacion = 0;


   /* boolean sexom;
    boolean sexof;
    boolean cargom;
    boolean cargoa;


    */
}
