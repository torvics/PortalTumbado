public class EA {
    public static void main(String[] args) {

        frm_Login miLogin = new frm_Login(null);

    }
}
